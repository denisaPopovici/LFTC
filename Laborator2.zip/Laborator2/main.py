import re


def hashing_func(key):
    #ascii code of first character % 11
	return ord(key[0]) % 11

def insert(hash_table, value):
    hash_key = hashing_func(value)

    if hash_table[hash_key] == None:
        hash_table[hash_key] = value
        return hash_key
    else:
        #solve collision
        #move to the next free spot
        for i in range(hash_key + 1, len(hash_table)):
            if hash_table[i] == None:
                hash_table[i] = value
                return i
        for i in range(0, hash_key):
            if hash_table[i] == None:
                hash_table[i] = value
                return i

def get_ts_code(hash_table, value):
    for i in range(len(hash_table)):
        if hash_table[i] == value:
            return i

file = open("read.txt")

operators = ['=', '+', '-', '*', '<', '>', '%']

key_words = ["int", "double", "#include", "<iostream>", "using", "namespace", "std", "while", "if", "cin", "cout", "main()", "return"]

separators = [':', ';', ',', "{", "}", "(", ")", "<<", ">>"]

forbidden = ['&&' , '||', '!', '@' , '#', '$', '^' , '&', '_', '~', '`', '.', '/', '?', '|', '\'', '"', ']', '[', '!=', '==', '>=', '<=', '->', '<-', '//']



a = file.read()

list = [] #list that contains all the atoms and what they represent
atoms = {} #list that contains all the atoms and their codes
fip_atom_codes = [] #list that contains all the atom codes in the fip table
fip_ts_codes = [] #list that contains all the ts codes in the fip table
hash_ts_codes = [None] * 11 #the ts table, the position of an element is that element's code

count = 0 #size of atoms
errors = ""

program = a.split("\n")
line_count = 0
for line in program:
    separator = ""
    tokens = line.split(' ')
    for token in tokens:
        if token in forbidden:
            #check if it is forbidden character
            errors += "Error at line " + str(line_count + 1) + ": " + str(token) + " is forbidden character\n"
        else:
            # check if it contains only forbidden characters
            contains_forbidden = 0
            for letter in token:
                if letter in forbidden:
                    contains_forbidden += 1
            if contains_forbidden == len(token):
                errors += "Error at line " + str(line_count + 1) + ": " + str(token) + " contains only forbidden characters\n"
            else:
                if token[-1] in separators:
                    separator = token[-1]
                    token = token[:-1]
                if token in operators:
                    list.append(token.strip() + " is operator")
                    if token not in atoms.keys():
                        atoms[token] = count
                        count = count + 1
                    fip_atom_codes.append(atoms[token])
                    fip_ts_codes.append('-')
                elif token in key_words:
                    list.append(token.strip() + " is key word")
                    if token not in atoms.keys():
                        atoms[token] = count
                        count = count + 1
                    fip_atom_codes.append(atoms[token])
                    fip_ts_codes.append('-')
                elif token in separators:
                    list.append(token.strip() + " is separator")
                    if token not in atoms.keys():
                        atoms[token] = count
                        count = count + 1
                    fip_atom_codes.append(atoms[token])
                    fip_ts_codes.append('-')
                elif token.isnumeric(): #integer
                    list.append(token.strip() + " is constant")
                    if 'CONST' not in atoms.keys():
                        atoms['CONST'] = count
                        count = count + 1
                    #get the ts code
                    if token not in hash_ts_codes:
                        ts_code = insert(hash_ts_codes, token)
                        fip_ts_codes.append(ts_code)
                    else:
                        ts_code = get_ts_code(hash_ts_codes, token)
                        fip_ts_codes.append(ts_code)
                    fip_atom_codes.append(atoms['CONST'])
                else: #double
                    aux = token.split(".")
                    ok = 1
                    for a in aux:
                        if not a.isnumeric():
                            ok = 0
                    if ok == 1:
                        list.append(token.strip() + " is constant")
                        if 'CONST' not in atoms.keys():
                            atoms['CONST'] = count
                            count = count + 1
                        if token not in hash_ts_codes:
                            ts_code = insert(hash_ts_codes, token)
                            fip_ts_codes.append(ts_code)
                        else:
                            ts_code = get_ts_code(hash_ts_codes, token)
                            fip_ts_codes.append(ts_code)
                        fip_atom_codes.append(atoms['CONST'])
                    else:
                        if token.strip() != "":
                            if token.isalpha(): #it contains only letters
                                if len(token) <= 8:
                                    list.append(token.strip() + " is identifier")
                                    if 'ID' not in atoms.keys():
                                        atoms['ID'] = count
                                        count = count + 1
                                    if token not in hash_ts_codes:
                                        ts_code = insert(hash_ts_codes, token)
                                        fip_ts_codes.append(ts_code)
                                    else:
                                        ts_code = get_ts_code(hash_ts_codes, token)
                                        fip_ts_codes.append(ts_code)
                                    fip_atom_codes.append(atoms['ID'])
                                else:
                                    errors += "Error at line " + str(line_count + 1) + ": " +  str(token) + " has size bigger than 8\n"
                            else:
                                errors += "Error at line " + str(line_count + 1) + ": " + str(token) + " should only contain letters\n"

                if separator != "":
                    list.append(separator.strip() + " is separator")
                    if separator.strip() not in atoms.keys():
                        atoms[separator.strip()] = count
                        count = count + 1
                    fip_atom_codes.append(atoms[separator])
                    fip_ts_codes.append('-')
                    separator=""
    line_count = line_count + 1

#remove duplicates
# list = set(list)
#
# # for el in list:
# #     print(el)
#
# print('\n')

if errors=="":
    print('----ATOMS AND THEIR CODES----')
    for el in atoms.items():
        print(el)

    print('\n----FIP----')
    for i in range(len(fip_atom_codes)):
        print(fip_atom_codes[i], fip_ts_codes[i])


    print('\n----TS----')
    for i in range(len(hash_ts_codes)):
        if hash_ts_codes[i] != None:
            print(i ,  hash_ts_codes[i])
else:
    print(errors)